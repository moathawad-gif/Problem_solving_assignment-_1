#include <iostream>
using namespace std;

int main() {
    int X, Y;
    
    cout <<"enter x:";
    cin >> X ;"\n";

    cout<<"enter y:";
    cin>>Y;

    cout << X << " + " << Y << " = " << X + Y << endl;
    cout << X << " * " << Y << " = " << X * Y << endl;
    cout << X << " - " << Y << " = " << X - Y << endl;

    return 0;
}