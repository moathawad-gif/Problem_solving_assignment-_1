#include <iostream>
#include <string>

using namespace std;

int main() {
    
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    string x;
    cout<<"enter a number:";
    cin >> x;

    int first_digit = x[0] - '0';

    if (first_digit % 2 == 0) {
        cout << "EVEN\n";
    } else {
        cout << "ODD\n";
    }

    return 0;
}