#include <iostream>
using namespace std;

int main() {
    int A, B;
    cout <<"enter A:";
    cin >> A;"\n";
    cout<<"enter b:";
    cin>>B;

    if (A >= B) {
        cout << "Yes";
    }
    else {
        cout << "No";
    }

    return 0;
}